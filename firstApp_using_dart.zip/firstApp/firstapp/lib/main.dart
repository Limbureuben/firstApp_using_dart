import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(

      home: Home(),
    ));

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('my first App'),
        backgroundColor: Colors.cyan[400],
        centerTitle: true,
      ),
      body: const Center(
        child: Text(
          'Hellow programmer',
          style: TextStyle(
            fontSize: 40.0,
            fontWeight: FontWeight.bold,
            letterSpacing: 2.0,
            color: Colors.cyan,
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Define the action to be taken when the button is pressed
        },
        backgroundColor: Colors.cyan[400],
        child: const Text('Click'),
      ),
    );
  }
}
